﻿namespace UiPath.Shared.Localization
{
    class SharedResources : AdobeSign.Activities.Properties.Resources
    {
    }
}