﻿namespace UiPath.Shared.Localization
{
    class SharedResources : AdobeSign.Properties.Resources
    {
    }
}