﻿
namespace AdobeSign.Models
{
    public class ErrorCode
    {
        public string code { get; set; }
        public string message { get; set; }

        public string error_description { get; set; }

        public string error { get; set; }

    }
}
