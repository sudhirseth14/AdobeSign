﻿namespace UiPath.Shared.Localization
{
    class SharedResources : AdobeSign.Activities.Design.Properties.Resources
    {
    }
}