namespace AdobeSign.Activities.Design.Designers
{
        /// <summary>
        /// Interaction logic for AdobeSignScopeDesigner.xaml
        /// </summary>
        public partial class AdobeSignScopeDesigner
        {
            public AdobeSignScopeDesigner()
            {
                InitializeComponent();
            }
        }
    
}
