namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetWorkflowDesigner.xaml
    /// </summary>
    public partial class GetWorkflowDesigner
    {
        public GetWorkflowDesigner()
        {
            InitializeComponent();
        }
    }
}
