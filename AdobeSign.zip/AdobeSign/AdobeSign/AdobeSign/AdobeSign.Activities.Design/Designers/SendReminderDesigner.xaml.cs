namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for SendReminderDesigner.xaml
    /// </summary>
    public partial class SendReminderDesigner
    {
        public SendReminderDesigner()
        {
            InitializeComponent();
        }
    }
}
