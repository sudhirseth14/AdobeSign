namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for RevokeTokenDesigner.xaml
    /// </summary>
    public partial class RevokeTokenDesigner
    {
        public RevokeTokenDesigner()
        {
            InitializeComponent();
        }
    }
}
