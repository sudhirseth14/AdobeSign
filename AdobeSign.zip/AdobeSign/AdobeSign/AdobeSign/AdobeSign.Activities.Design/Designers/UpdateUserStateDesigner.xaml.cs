namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UpdateUserStateDesigner.xaml
    /// </summary>
    public partial class UpdateUserStateDesigner
    {
        public UpdateUserStateDesigner()
        {
            InitializeComponent();
        }
    }
}
