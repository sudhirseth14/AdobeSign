namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetAllGroupsDesigner.xaml
    /// </summary>
    public partial class GetAllGroupsDesigner
    {
        public GetAllGroupsDesigner()
        {
            InitializeComponent();
        }
    }
}
