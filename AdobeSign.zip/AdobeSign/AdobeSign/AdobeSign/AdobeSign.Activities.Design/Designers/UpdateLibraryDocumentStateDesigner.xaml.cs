namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UpdateLibraryDocumentStateDesigner.xaml
    /// </summary>
    public partial class UpdateLibraryDocumentStateDesigner
    {
        public UpdateLibraryDocumentStateDesigner()
        {
            InitializeComponent();
        }
    }
}
