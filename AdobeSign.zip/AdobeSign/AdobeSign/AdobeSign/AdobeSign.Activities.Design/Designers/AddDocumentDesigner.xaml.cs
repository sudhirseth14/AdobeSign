namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for AddDocumentDesigner.xaml
    /// </summary>
    public partial class AddDocumentDesigner
    {
        public AddDocumentDesigner()
        {
            InitializeComponent();
        }
    }
}
