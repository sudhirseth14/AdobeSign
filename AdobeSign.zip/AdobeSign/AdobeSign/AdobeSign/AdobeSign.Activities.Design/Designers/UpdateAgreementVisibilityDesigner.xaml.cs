namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UpdateAgreementVisibilityDesigner.xaml
    /// </summary>
    public partial class UpdateAgreementVisibilityDesigner
    {
        public UpdateAgreementVisibilityDesigner()
        {
            InitializeComponent();
        }
    }
}
