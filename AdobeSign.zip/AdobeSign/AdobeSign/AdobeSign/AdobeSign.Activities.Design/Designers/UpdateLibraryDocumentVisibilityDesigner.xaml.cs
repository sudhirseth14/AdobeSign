namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UpdateLibraryDocumentVisibilityDesigner.xaml
    /// </summary>
    public partial class UpdateLibraryDocumentVisibilityDesigner
    {
        public UpdateLibraryDocumentVisibilityDesigner()
        {
            InitializeComponent();
        }
    }
}
