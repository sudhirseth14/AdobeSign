namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for DeleteAgreementDesigner.xaml
    /// </summary>
    public partial class DeleteAgreementDesigner
    {
        public DeleteAgreementDesigner()
        {
            InitializeComponent();
        }
    }
}
