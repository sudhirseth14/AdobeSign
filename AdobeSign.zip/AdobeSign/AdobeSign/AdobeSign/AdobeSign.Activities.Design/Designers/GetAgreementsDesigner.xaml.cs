namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetAgreementsDesigner.xaml
    /// </summary>
    public partial class GetAgreementsDesigner
    {
        public GetAgreementsDesigner()
        {
            InitializeComponent();
        }
    }
}
