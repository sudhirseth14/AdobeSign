namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UpdateAgreementStateDesigner.xaml
    /// </summary>
    public partial class UpdateAgreementStateDesigner
    {
        public UpdateAgreementStateDesigner()
        {
            InitializeComponent();
        }
    }
}
