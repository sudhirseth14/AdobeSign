namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetUserDesigner.xaml
    /// </summary>
    public partial class GetUserDesigner
    {
        public GetUserDesigner()
        {
            InitializeComponent();
        }
    }
}
