namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetAllUsersDesigner.xaml
    /// </summary>
    public partial class GetAllUsersDesigner
    {
        public GetAllUsersDesigner()
        {
            InitializeComponent();
        }
    }
}
