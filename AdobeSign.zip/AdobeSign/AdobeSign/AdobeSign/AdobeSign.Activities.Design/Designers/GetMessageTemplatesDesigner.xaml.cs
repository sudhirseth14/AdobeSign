namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetMessageTemplatesDesigner.xaml
    /// </summary>
    public partial class GetMessageTemplatesDesigner
    {
        public GetMessageTemplatesDesigner()
        {
            InitializeComponent();
        }
    }
}
