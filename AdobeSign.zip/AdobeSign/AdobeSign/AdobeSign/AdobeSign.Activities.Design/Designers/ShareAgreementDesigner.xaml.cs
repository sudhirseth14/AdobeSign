namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for ShareAgreementDesigner.xaml
    /// </summary>
    public partial class ShareAgreementDesigner
    {
        public ShareAgreementDesigner()
        {
            InitializeComponent();
        }
    }
}
