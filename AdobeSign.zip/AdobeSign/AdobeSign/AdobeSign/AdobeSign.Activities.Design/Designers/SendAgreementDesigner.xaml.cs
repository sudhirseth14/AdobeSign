namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for SendAgreementDesigner.xaml
    /// </summary>
    public partial class SendAgreementDesigner
    {
        public SendAgreementDesigner()
        {
            InitializeComponent();
        }
    }
}
