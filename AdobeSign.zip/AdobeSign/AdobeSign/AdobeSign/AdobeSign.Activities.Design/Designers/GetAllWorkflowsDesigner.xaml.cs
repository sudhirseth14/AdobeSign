namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetAllWorkflowsDesigner.xaml
    /// </summary>
    public partial class GetAllWorkflowsDesigner
    {
        public GetAllWorkflowsDesigner()
        {
            InitializeComponent();
        }
    }
}
