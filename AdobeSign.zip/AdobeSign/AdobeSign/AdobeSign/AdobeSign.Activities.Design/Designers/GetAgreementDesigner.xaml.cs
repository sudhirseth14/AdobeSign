namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetAgreementDesigner.xaml
    /// </summary>
    public partial class GetAgreementDesigner
    {
        public GetAgreementDesigner()
        {
            InitializeComponent();
        }
    }
}
