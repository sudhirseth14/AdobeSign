namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetUsersOfGroupDesigner.xaml
    /// </summary>
    public partial class GetUsersOfGroupDesigner
    {
        public GetUsersOfGroupDesigner()
        {
            InitializeComponent();
        }
    }
}
