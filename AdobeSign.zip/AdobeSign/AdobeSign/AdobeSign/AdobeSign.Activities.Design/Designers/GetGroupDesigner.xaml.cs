namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetGroupDesigner.xaml
    /// </summary>
    public partial class GetGroupDesigner
    {
        public GetGroupDesigner()
        {
            InitializeComponent();
        }
    }
}
