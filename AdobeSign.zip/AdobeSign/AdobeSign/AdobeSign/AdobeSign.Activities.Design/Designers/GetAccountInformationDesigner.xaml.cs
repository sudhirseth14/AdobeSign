namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetAccountInformationDesigner.xaml
    /// </summary>
    public partial class GetAccountInformationDesigner
    {
        public GetAccountInformationDesigner()
        {
            InitializeComponent();
        }
    }
}
