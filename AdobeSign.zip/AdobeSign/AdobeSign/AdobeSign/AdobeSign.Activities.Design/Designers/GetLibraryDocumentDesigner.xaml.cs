namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetLibraryDocumentDesigner.xaml
    /// </summary>
    public partial class GetLibraryDocumentDesigner
    {
        public GetLibraryDocumentDesigner()
        {
            InitializeComponent();
        }
    }
}
