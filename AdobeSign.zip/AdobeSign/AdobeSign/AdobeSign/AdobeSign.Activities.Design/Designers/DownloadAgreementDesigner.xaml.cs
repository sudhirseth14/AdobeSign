namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for DownloadAgreementDesigner.xaml
    /// </summary>
    public partial class DownloadAgreementDesigner
    {
        public DownloadAgreementDesigner()
        {
            InitializeComponent();
        }
    }
}
