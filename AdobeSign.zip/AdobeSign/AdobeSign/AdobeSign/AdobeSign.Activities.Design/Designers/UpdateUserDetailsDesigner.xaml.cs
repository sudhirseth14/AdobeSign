namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for UpdateUserDetailsDesigner.xaml
    /// </summary>
    public partial class UpdateUserDetailsDesigner
    {
        public UpdateUserDetailsDesigner()
        {
            InitializeComponent();
        }
    }
}
