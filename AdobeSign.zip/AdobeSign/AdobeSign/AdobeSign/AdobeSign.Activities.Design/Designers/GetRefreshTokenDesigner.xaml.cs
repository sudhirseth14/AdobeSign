namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetRefreshTokenDesigner.xaml
    /// </summary>
    public partial class GetRefreshTokenDesigner
    {
        public GetRefreshTokenDesigner()
        {
            InitializeComponent();
        }
    }
}
