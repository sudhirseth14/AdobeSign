namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetGroupsOfUserDesigner.xaml
    /// </summary>
    public partial class GetGroupsOfUserDesigner
    {
        public GetGroupsOfUserDesigner()
        {
            InitializeComponent();
        }
    }
}
