namespace AdobeSign.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for GetSigningURLDesigner.xaml
    /// </summary>
    public partial class GetSigningURLDesigner
    {
        public GetSigningURLDesigner()
        {
            InitializeComponent();
        }
    }
}
